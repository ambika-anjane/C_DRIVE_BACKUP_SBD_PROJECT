import pandas as pd
import sys
import yaml
import logging
#from generalapi_logger import *
from datetime import date, datetime
import requests_cache
from time import sleep
from genericAPI import genericAPI as genapi
from genericAPI import CustomException
from datetime import datetime, timedelta, date
import datetime

#now = datetime.now().strftime('%Y%m%d%H%M%S')
#my_logger = get_logger('ProcessExcelStaticFile_{}.log'.format(now))

def main():
    try:
        processName = sys.argv[1]
        print(processName)
        excelFileName, srcSheet, srcRecName, Required_Columns, snowflakeConnection = genapi().getExcelFileLoadInfo(processName)
        print(excelFileName)
        #if processName == 'GLOBAL-MARKET-SIZE-IN-VALUE':
        #   if 'Global-Market Size in Value' in srcSheet:
        #       print(srcSheet)
        

        
        euro_dfs = pd.read_excel(excelFileName, srcSheet , index_col=False)
        euro_dfs.columns = Required_Columns
        df_sheet = pd.DataFrame(euro_dfs)
        df_sheet.columns = Required_Columns
        print(df_sheet.columns)
        df_sheet.columns = map(lambda x: str(x).upper(), df_sheet.columns)
        df_sheet = genapi().df_include_landing_audit_columns(df_sheet, srcRecName)
        df_sheet = genapi().fix_date_cols(df_sheet)
            #df_sheet.to_csv('C:/ambika/SBD_PROJECT/test2.csv',index = False)
            
     
        print(df_sheet)
        snowflakeAccount = 'sbd_caspian.us-east-1'
        snowflakeUser = 'DEV_INGEST'
        snowflakePass = 'poonooD9fooBeth9'
        snowflakeWarehouse = 'DEV_INGEST_WH'
        snowflakeDatabase = 'DEV_RAW' 
        snowflakeSchema = 'EUROMONITOR'
        snowflakeTableName = "DATAMETRICS_INFLATION_LANDING"
        
        genapi().write_snowflake_data(snowflakeAccount, snowflakeUser, snowflakePass, snowflakeWarehouse,
                                            snowflakeDatabase, snowflakeSchema, snowflakeTableName, df_sheet)
    except Exception as e:
        #my_logger.info("An exception occured.")
        print('An Exception occured in main function.', e)
        sys.exit(1)


if __name__ == '__main__':
    main()
